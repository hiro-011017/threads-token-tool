module.exports = {
  spreadsheetId: "ここにスプレッドシートIDを貼ってください",
  sheetIndex: 0,
  authJsonPath: "./auth.json"
};